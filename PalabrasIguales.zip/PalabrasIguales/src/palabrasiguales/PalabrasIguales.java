
package palabrasiguales;

import java.util.Scanner;


public class PalabrasIguales {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Primer palabra");
        String palabra1 = entrada.next();
        System.out.println("Segunda palabra");
        String palabra2 = entrada.next();
        
        if (palabra1.equals(palabra2)) {
            System.out.println("si son iguales");
        }else{
            System.out.println("no son iguales");
        }
        
    }
    
}
