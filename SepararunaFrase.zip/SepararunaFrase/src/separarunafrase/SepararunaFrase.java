
package separarunafrase;

import java.util.Scanner;


public class SepararunaFrase {

   
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        entrada.useDelimiter("\n");
         
        System.out.println("Escribe una frase");
        String frase=entrada.next();
        
        String palabras[] = frase.split(" ");
         
        for(int i=0;i<palabras.length;i++){
            System.out.println(palabras[i]);
        }
    }
    
}
