
package calculadoraporconsola;

import java.util.Locale;
import java.util.Scanner;

public class CalculadoraporConsola {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US);
        
        double Numero1;
        double Numero2;
        double resultado=0;
  
        System.out.println("Escribe el Numero 1");
        Numero1=sc.nextDouble();
         
        System.out.println("Escribe el codigo de operacion\n"
                + "+"+" "+"-"+" "+"*"+" "+"/"+" "+"^"+" "+"%\n");
        String operacion = sc.next();
         
        System.out.println("Escribe el Numero 2");
        Numero2=sc.nextDouble();
  
        
        switch (operacion){
            case "+":
                resultado=Numero1+Numero2;
                break;
            case "-":
                resultado=Numero1-Numero2;
                break;
            case "*":
                resultado=Numero1*Numero2;
                break;
            case "/":
                resultado=Numero1/Numero2;
                break;
            case "^":
                resultado=(int)Math.pow(Numero1, Numero2);
                break;
            case "%":
                resultado=Numero1%Numero2;
                break;
        }
  
        System.out.println( Numero1+" "+operacion+" "+Numero2+" = "+resultado);
  
    }
    
}
