
package remplazar.letras;

public class RemplazarLetras {

    public static void main(String[] args) {
        
        String cadena="una niña floto sobre mi y volo un auto con su rasho laser";
        //modifica el String
        System.out.print(cadena.replace('a', 'e'));
    }
    
}
