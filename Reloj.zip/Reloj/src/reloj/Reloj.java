
package reloj;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class Reloj {

    public static void main(String[] args) {
        
        //time 
        LocalTime horaActual = LocalTime.now();
        System.out.println("hora actual :"+ horaActual);
        //date
        LocalDate fechaActual =LocalDate.now();
        System.out.println("\nfecha actual :" + fechaActual);
        //time and date
        LocalDateTime horayfecha =  LocalDateTime.now();
        System.out.println("\nla hora y fecha es :"+horayfecha);
    }
    
}
