package sacarletras;

import java.util.Scanner;

public class SacarLetras {

    public static void main(String[] args) {
        System.out.println("Escribe una palabra");
        Scanner entrada = new Scanner(System.in);
        String cadena = entrada.nextLine();
        String subcadena = cadena.substring(5);
        System.out.println(subcadena);
    }

}
